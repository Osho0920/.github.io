import ctypes
ENABLE_PROCESSED_OUTPUT = 0x0001
ENABLE_WRAP_AT_EOL_OUTPUT = 0x0002
ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
MODE = ENABLE_PROCESSED_OUTPUT + ENABLE_WRAP_AT_EOL_OUTPUT + ENABLE_VIRTUAL_TERMINAL_PROCESSING
kernel32 = ctypes.windll.kernel32
handle = kernel32.GetStdHandle(-11)
kernel32.SetConsoleMode(handle, MODE)
RED = '\033[91m'
END = '\033[0m'

FIRST_CHECK_ERROR = '1文字目は数字を入力してください'
WORD_ERROR = '数字または演算子以外は入力できません'
ZERO_DIVISION_ERROR = '０割はできません'

def error_print(error_message):
    print(RED + error_message + END)
    