from logic import error as e
import re
import operator as ope
import math
    
class Calculator:
    input_value = str()
    input_history = str()
    input_list = list()
        
    def first_check(self):
        if not self.input_list and \
           not self.input_value.lower() == 'exit' and \
           not self.input_value.lower() == 'c':
            try:
                num = int(self.input_value)
                self.input_list.append(num)
                self.input_history = self.input_value
            except ValueError:
                e.error_print(e.FIRST_CHECK_ERROR)
                return True
        return False
    
    def discrimination(self):
        if re.match(r'[\+\-*/%=cCexitEXIT]', self.input_value):
            if self.input_value.lower() == 'c'\
               or self.input_value.lower() == 'exit' \
               or not re.match(r'.?[a-zA-Z\d]', self.input_value):
                return False
        if re.match(r'[\d]', self.input_value):
            return False
        e.error_print(e.WORD_ERROR)
        return True
    
    def update(self):
        self.input_list[-1] = self.input_value
        self.input_history = str()
        for value in self.input_list:
            self.input_history = (self.input_history + ' ' + value).strip()
    
    def result(self):
        """
        try:
            result = round(eval(self.input_history))
            print(f'{self.input_history}{self.input_value}{result}')
            print(f'{result}')
        except:
            print('０割はできません')
        finally:
            self.clears()
        """
        try:
            self.high_priority()
            self.low_priority()
            self.show_results()
            
        except ZeroDivisionError:
            e.error_print(e.ZERO_DIVISION_ERROR)
            self.clears()
            
    def clears(self):
        self.input_history = str()
        self.input_list.clear()
    
    def value_append(self):
        self.input_list.append(self.input_value)
        self.input_history = self.input_history + ' '+ self.input_value
        
    def high_priority(self):
        while '*' in self.input_list \
                or '/' in self.input_list\
                or '%' in self.input_list:
            for index in range(len(self.input_list)):
                if re.match(r'[*/%]', str(self.input_list[index])):
                    self.calc_process(index)
                    break
                   
    def low_priority(self):
        while len(self.input_list) != 1:
                for index in range(len(self.input_list)):
                    if re.match(r'[\+\-]', str(self.input_list[index])):
                        self.calc_process(index)
                        break
                    
    def calc(self, value_left, value_right, operator):
        if operator == '*':
            return ope.mul(int(value_left), int(value_right))
        if operator == '/':
            return math.floor(ope.truediv(int(value_left), int(value_right)))
        if operator == '%':
            return ope.mod(int(value_left), int(value_right))
        if operator == '+':
            return ope.add(int(value_left), int(value_right))
        if operator == '-':
            return ope.sub(int(value_left), int(value_right))

    def calc_process(self, index):
        self.input_list[index-1] = self.calc(self.input_list[index-1], \
                                             self.input_list[index+1], \
                                             self.input_list[index])
        self.input_list.pop(index)
        self.input_list.pop(index)
        
    def show_results(self):
        result = self.input_list[0]
        if '=' in self.input_history:
            print(f'{self.input_history} {result}')
        else:
            print(f'{self.input_history} {self.input_value} {result}')
        self.input_history = str(result)