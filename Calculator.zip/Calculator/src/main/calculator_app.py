import os
import sys
sys.path.append(os.path.abspath(''))
#print(sys.path)
sys.path[-1] = sys.path[-1].replace('main','')
#print(sys.path)
from logic.calculator import Calculator
import re

print('電卓アプリ')
c = Calculator()
while True:
    if c.input_history != '':
        print(c.input_history)
        
    c.input_value = input('数字または演算子を入力してください＞')
    
    if c.first_check():
        continue
    
    if c.discrimination():
        continue
    
    if c.input_value.lower() == 'c':
        print('クリア')
        c.clears()
        continue
    
    if c.input_value.lower() == 'exit':
        sys.exit('終了します')
    
    if re.match(r'\d',str(c.input_list[-1])) and re.match(r'\d', c.input_value) \
       or re.match(r'[\+\-*/%]',c.input_list[-1]) and re.match(r'[\+\-*/%=]', c.input_value):
        c.update()
        if c.input_value == '=':
            del c.input_list[-1]
            c.result()
        continue
    
    if c.input_value == '=':
        c.result()
        continue
    
    c.value_append()